// Total.jsx
import { useSelector } from "react-redux";

export default function Total() {
  const cartItems = useSelector((state) => state.product.cartItems);
  const shippingCost = useSelector((state) => state.product.shippingCost);
  const shippingMethod = useSelector((state) => state.product.shippingMethod);

  // CALCULATE SUBTOTAL (sum of item prices)
  const subtotal =
    cartItems?.reduce((acc, item) => acc + Number(item.price), 0) ?? 0;

    // CALCULATE TOTAL
  const total = subtotal + shippingCost;

  if (!shippingMethod) return null;

  return (
    <div>
      <h3>TOTAL:</h3>
      <p>R {total}</p>
    </div>
  );
}
