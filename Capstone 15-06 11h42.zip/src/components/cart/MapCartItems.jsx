// MapCartItems.jsx
import { useSelector, useDispatch } from "react-redux";
import { Container, Row, Col } from "react-bootstrap";
import CartProductCard from "./CartProductCard";
// import { remove } from "../../redux/ProductSlice";

export default function MapCartItems() {
  const cartItems = useSelector((state) => state.product.cartItems);
  // const dispatch = useDispatch();

  // const handleRemove = (product) => {
  //   dispatch(remove(product));
  // };

  return (
    <Container>
      <Row>
        {cartItems.map((product) => (
          <Col className="d-flex" key={product.id} xs={12} sm={6} md={4} lg={3}>
            <CartProductCard product={product}/>
            {/* //  remove={handleRemove} /> */}
          </Col>
        ))}
      </Row>
    </Container>
  );
}
