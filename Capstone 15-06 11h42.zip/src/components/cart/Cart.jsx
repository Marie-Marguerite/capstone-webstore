// Cart.jsx

import MapCartItems from "./MapCartItems";
import Subtotal from "./Subtotal";
import Shipping from "./Shipping";
import Total from "./Total";

export default function Cart() {
  return (
    <>
      <section>
        <MapCartItems />
      </section>
      <section>
        <hr/>
        <Subtotal />
        <Shipping />
        <Total />
      </section>
    </>
  );
}
