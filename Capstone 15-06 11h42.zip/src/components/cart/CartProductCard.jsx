// CartProductCard.jsx
import { Container, Row, Col } from "react-bootstrap";
import { useDispatch } from "react-redux";
import { decreaseQuantity, increaseQuantity, removeItem } from "../../redux/ProductSlice";

export default function CartProductCard({ product }) {
  const dispatch = useDispatch();

  return (
    <Container>
      <Row>
        <Col>
          {/* IMAGE */}
          <img
            src={product.imageURL}
            alt={`Image of ${product.title}`}
            className="cartImage"
          />
        </Col>

        <Col>
          {/* NAME, COLOR, QTY */}
          <div>
            <div>
              <p>{product.title}</p>
              <p>{product.color || "No colour selected"}</p>
            </div>
            <div>
              <p>
                Qty:
                <button onClick={() => dispatch(decreaseQuantity(product))}>
                  -
                </button>
                {product.quantity}
                <button onClick={() => dispatch(increaseQuantity(product))}>+</button>
              </p>
            </div>
          </div>
        </Col>

        <Col>
          {/* PRICE, REMOVE */}
          <div>R {product.price}</div>
          <div>
            <button
              onClick={() => {
                dispatch(removeItem(product));
              }}
            >
              remove
            </button>
          </div>
        </Col>
      </Row>
    </Container>
  );
}
