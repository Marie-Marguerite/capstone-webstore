// ShippingInfo.jsx
import styles from "./ShippingInfo.module.css";
import React, { useState } from "react";

export default function ShippingInfo() {
  const [isViewingInfo, setIsViewingInfo] = useState(false);

  return (
    <>
      {/* 1. BUTTON: INFO ICON (to open)*/}
      <div className={styles.infoButtonContainer}>
        <button
          className={styles.infoButton}
          onClick={() => setIsViewingInfo(true)}
        >
          i
        </button>
      </div>

      {/* 2. POPUP OVERLAY */}
      {isViewingInfo && (
        <div className={styles.popupOverlay}>
          <div className={styles.popup}>
            {/* - heading */}
            <h2>Shipping Options Guide</h2>

            {/* - instruction content */}
            <ul className={styles.popupList}>
              <li>
                <span className={styles.spanWhite}>PICK UP</span> - come and
                collect your parcel from our boutique{" "}
                <span className={styles.spanWhite}>R 0.00</span>.
              </li>
              <li>
                <span className={styles.spanWhite}>STANDARD SHIPPING</span> - 3
                to 5 business days for domestic delivery{" "}
                <span className={styles.spanWhite}>R 150.00</span>.
              </li>
              <li>
                <span className={styles.spanWhite}>EXPRESS SHIPPING</span> -
                next day delivery for orders placed before 15:30 or 1 business
                day for orders placed after 15:30 at{" "}
                <span className={styles.spanWhite}>R 350.00</span>.
              </li>
              <li>
                <span className={styles.spanWhite}>INTERNATIONAL SHIPPING</span>{" "}
                - 2 to 3 weeks for deliveries outside South Africa{" "}
                <span className={styles.spanWhite}>R 2500.00</span>.{" "}
              </li>
              <li>
                Please note that shipping and relating costs are non-refundable
              </li>
            </ul>

            {/* - button (to close) */}
            <button
              className={styles.closeButton}
              onClick={() => setIsViewingInfo(false)}
            >
              ✖
            </button>
          </div>
        </div>
      )}
    </>
  );
}
