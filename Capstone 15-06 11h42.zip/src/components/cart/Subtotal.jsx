// Subtotal.jsx
import { useSelector } from "react-redux";

export default function Subtotal() {
  const cartItems = useSelector((state) => state.product.cartItems);

  // CALCULATE SUBTOTAL (sum of item prices)
  const subtotal =
    cartItems?.reduce((acc, item) => acc + Number(item.price), 0) ?? 0;

  return (
    <div>
      <h3>Subtotal:</h3>
      <p>R {subtotal}</p>
    </div>
  );
}
