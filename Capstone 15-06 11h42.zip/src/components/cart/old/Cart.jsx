// Cart.jsx
import { useSelector } from "react-redux";
import Shipping from "../Shipping";


export default function Cart() {
  const cartItems = useSelector((state) => state.product.cartItems);
  const shippingCost = useSelector((state) => state.product.shippingCost);
  const shippingMethod = useSelector((state) => state.product.shippingMethod);

  // SUBTOTAL (sum of item prices)
  const subtotal =
    cartItems?.reduce((acc, item) => acc + Number(item.price), 0) ?? 0;

  // TOTAL (subtotal + shipping)
  const total = subtotal + shippingCost;

  return (
    // MAP CART ITEMS

    <section>
      {/* - subtotal */}
      <div>
        <h3>Subtotal:</h3>
        <p>R {subtotal}</p>
      </div>
      {/* - shipping */}
      <div>
        {" "}
        <Shipping />
        <p>R {shippingCost}</p>
      </div>
      {/* - total  */}
      {/*   show total if shippingMethod is selected */}
      {shippingMethod && (
        <div>
          <h3>TOTAL:</h3>
          <p>R {total}</p>
        </div>
      )}
    </section>
  );
}
