// Shipping.jsx
import { useSelector, useDispatch } from "react-redux";
import {setShipping} from '../../redux/ProductSlice';
import ShippingInfo from "./ShippingInfo";

export default function Shipping () {
    const dispatch = useDispatch();
    // const shipping = useSelector((state)=> state.product.shipping);

    // SHIPPING
    const handleShippingChange= (event) => {
        const selected = event.target.value;
        const cost = Number(selected);
        const method = event.target.options[event.target.selectedIndex].text;
        dispatch(setShipping({cost, method}));
    }

    return(
        <>
        {/* SHIPPING OPTIONS */}
        <select onChange={handleShippingChange}>
            <option value="0">Pick up | R 0</option>
            <option value="150">Standard shipping | R150</option>
            <option value="350">Express shipping | R350</option>
            <option value="2500">International shipping | R2500</option>
        </select>

        {/* SHIPPING INFO POPUP */}
        <ShippingInfo/> 
        </>
    )
}; 
