// HeaderNav.jsx
import React from "react";
import { Link } from "react-router-dom";
import Logo from "../../assets/Logo.png";
import UserSlice from "../../redux/UserSlice";
// import { useSelector } from "react-redux";

export default function HeaderNav() {
  return (
    <nav className="navContainer">
      <img id="logoNav" src={Logo} alt="Ferm Living Logo" />
      <div className="nav">
        <div>
          <Link to="/">HOME</Link>
        </div>
        <div>
          <Link to="/products">PRODUCTS</Link>
        </div>
        <div>
          <Link to="/about">ABOUT</Link>
        </div>
      </div>
    </nav>
  );
}
