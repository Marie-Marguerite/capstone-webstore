// Footer.jsx
import styles from "./styles/footer.module.css";
import { Link } from "react-router-dom";
// Using FontAwesome for the Instagram icon instead of an <img> tag
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faInstagram } from "@fortawesome/free-brands-svg-icons";

export default function Footer() {
  return (
    <footer className={styles.footer}>
      {/* 1. TEXT AND LINKS */}
      <div className={styles.footerContent}>
        {/* //todo add something here  */}
        <p className={styles.footerCopyRight}>???????</p>

        {/* - About link */}
        <Link to="/about">ABOUT</Link>

        {/* - Instagram link */}
        <a
          className={styles.footerInstagram}
          href="https://www.instagram.com/fermliving/?hl=en"
          target="_blank"
          rel="noopener noreferrer"
        >
          <FontAwesomeIcon icon={faInstagram} />
        </a>
      </div>

      {/* 2. BLOCK */}
      <div>
        <Link to="/products">SHOP</Link>
        <Link to="/cart">CART</Link>
      </div>
    </footer>
  );
}
