// Products.jsx
import React from "react";
import Counter from "./Counter.jsx";
import MapProductCards from "./MapProductCards.jsx";
import Footer from "../general/Footer.jsx";

export default function Products() {
  return (
    <>
      {/* DISPLAY TOTAL CART ITEMS */}
      <Counter />
      {/* PRODUCTS */}
      <section>
        <MapProductCards />
      </section>
      {/* FOOTER */}
      <footer>
        <Footer />
      </footer>
    </>
  );
}
