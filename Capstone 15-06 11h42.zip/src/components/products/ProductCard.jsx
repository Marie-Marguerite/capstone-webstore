// ProductCard.jsx
import { useState } from "react";
import { Card, Button } from "react-bootstrap";
import ColorDropdown from "./ColorDropdown";

export default function ProductCard({ product, handleBuy }) {
  // COLOR SELECTOR
  const [selectedColor, setSelectedColor] = useState("");
  const [selectError, setSelectError] = useState("");

  const handleSelectColor = (color) => {
    setSelectedColor(color);
  };

  return (
    <Card className="card">
      {/* CARD IMAGE */}
      <Card.Img
        src={product.imageURL}
        alt={`Image of ${product.title}`}
        className="cardImage"
      />

      {/* CARD BODY*/}
      <Card.Body className="cardBody">
        {/* Card Title and Price */}
        <Card.Title className="cardTitle">{product.title}</Card.Title>
        <Card.Text>R {product.price.toFixed(2)}</Card.Text>

        {/* COLOR DROPDOWN */}
        <ColorDropdown
          productId={product.id}
          colors={product.colors}
          selectedColor={selectedColor}
          onSelectColor={handleSelectColor}
        />

        {/* CARD BUY BUTTON */}
        <Button
          onClick={() => {
            if (!selectedColor) {
              setSelectError("Please first select a colour.");
              return;
            }
            setSelectError("");
            handleBuy({ ...product, color: selectedColor });
          }}
        >
          BUY
        </Button>
        {selectError && <p>{selectError}</p>}

        {/* CARD DESCRIPTION */}
        <Card.Text>{product.description}</Card.Text>
      </Card.Body>
    </Card>
  );
}
