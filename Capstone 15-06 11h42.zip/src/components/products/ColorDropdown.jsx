// ColorDropdown.jsx
import { Dropdown, DropdownButton } from "react-bootstrap";

export default function ColorDropdown({
  productId,
  colors,
  selectedColor,
  onSelectColor,
}) {
  return (
    <DropdownButton
      id={`dropdown-${productId}`}
      title={selectedColor || "colour"}
      onSelect={onSelectColor}
    >
      {colors.map((color, index) => (
        <Dropdown.Item key={index} eventKey={color}>
          {color}
        </Dropdown.Item>
      ))}
    </DropdownButton>
  );
}
