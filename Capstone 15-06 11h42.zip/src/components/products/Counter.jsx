// Counter.jsx
//todo  addedToCart: false, // todo make use of this when styling

import React from "react";
// import styles from "./styles/CartItemsCounter.module.css";
import { useSelector } from "react-redux";

export default function CartItemsCounter() {
  //* COUNT BOUGHT ITEMSs
  //  SELECT/GET NR OF BOUGHT ITEMS FROM STATE/STORE
  const cartItemsCount = useSelector(
    (state) => state.boughtItems.list.length
  );

  /* If no cartItemsCount, don't display Counter component */
  if (!cartItemsCount || cartItemsCount === 0) return null;
  
  return (
    //* DISPLAY NR OF BOUGHT ITEMS

    <div className={styles.counter}>{cartItemsCount}</div>
  );
}
