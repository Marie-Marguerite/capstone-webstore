// MapProductCards.jsx
import React, { useState } from "react";
import { Card, Button, Container, Row, Col } from "react-bootstrap";
import Dropdown from "react-bootstrap/Dropdown";
import DropdownButton from "react-bootstrap/DropdownButton";
import ProductWithImageArray from "./ProductArray.jsx";

export default function MapProductCards({ handleBuy }) {
  //* 1. COLOR SELECTOR
  //* 1.1 Initialize state variable
  const [selectedColor, setSelectedColor] = useState({});

  //* 1.2 Handle color selection (dropdown button)
  //  remember all previously selected color too
  const handleSelectColor = (productId, color) => {
    setSelectedColor((prev) => ({
      ...prev,
      [productId]: color,
    }));
  };

  //* 2. PRODUCT CARDS
  return (
    <>
      <Container>
        <Row>
          {/* MAP FROM THE ARRAY */}
          {ProductWithImageArray.map((product) => (
            <Col
              className="d-flex"
              key={product.id}
              xs={12}
              sm={6}
              md={4}
              lg={3}
            >
              <Card className="card">
                {/* CARD IMAGE */}
                <Card.Img
                  src={product.imageURL}
                  alt={`Image of ${product.title}`}
                  className="cardImage"
                />
                {/* CARD BODY*/}
                <Card.Body className="cardBody">
                  {/* Card Title and Price */}
                  <Card.Title className="cardTitle">{product.title}</Card.Title>
                  <Card.Text>R {product.price.toFixed(2)}</Card.Text>
                  
                  {/* CARD DROPDOWN: color selection */}
                  <DropdownButton
                    id={`dropdown-${product.id}`}
                    title={selectedColor[product.id] || "colour "}
                    onSelect={(color) => handleSelectColor(product.id, color)}
                  >
                    {product.colors.map((color, index) => (
                      <Dropdown.Item key={index} eventKey={color}>
                        {color}
                      </Dropdown.Item>
                    ))}
                  </DropdownButton>

                  {/* CARD BUY BUTTON */}
                  <Button onClick={() => handleBuy(product.price)}>BUY</Button>
                  
                  {/* CARD DESCRIPTION */}
                  <Card.Text>{product.description}</Card.Text>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </Container>
    </>
  );
}
