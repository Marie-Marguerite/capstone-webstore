// About.jsx
import LogoBird from "../../assets/LogoBird.jpg";
import { Figure, Row, Col, Container } from "react-bootstrap";

export default function About() {
  return (
    <Container className="about">
      {/* ROW 1 */}
      <Row>
        {/* IMAGE 1 */}
        <Col>
          <Figure>
            <Figure.Image
              className="img-fluid"
              width={500}
              alt="Photograph of the boutique store featuring Ferm Living home decor products"
              src="https://fermliving.com/cdn/shop/files/1_SS25_Boutique_1000x1154_594d3328-1508-4a09-8a5f-3c49bd726d0d.jpg?v=1742389277&width=1000"
            />
          </Figure>
        </Col>
        {/* IMAGE 2 */}
        <Col>
          <Figure>
            <Figure.Image
              className="img-fluid"
              width={300}
              src="https://fermliving.com/cdn/shop/files/Styling_Session_Banners_2_530009d4-1897-4d07-a322-e9998cecc19d.jpg?v=1725284399&width=1000"
              alt="Photograph of fabric swatches being handled"
            />
          </Figure>
        </Col>
      </Row>

      {/* ROW 2 */}
      <Row>
        {/* DESCRIPTION */}
        <section className="aboutDescription">
          <h1 className="aboutDescriptionHeading">ABOUT FIRM LIVING</h1>
          <p>
            Life is full of contrasts. As we navigate expectations and dreams in
            search of meaning and comfort, we long for a balanced life with room
            to be ourselves. A place where we can realise the true value of
            things and feel at home. Driven by a love for authentic design and a
            commitment to responsible choices, we craft honest products and calm
            environments that help you balance life’s contrasts.
          </p>
          <p>
            From our home in Copenhagen, we collaborate with artisans around the
            world, fusing our Scandinavian mindset with global skills and
            traditions.{" "}
          </p>
          <p>
            Our collections are defined by soft forms, rich textures, and
            curious details, allowing you to create composed atmospheres with a
            touch of the unexpected. From materials and processes to production
            and delivery, we challenge ourselves to help shape a sustainable
            future, making it easier for you to make responsible choices. We
            create collections of furniture, accessories and lighting, so you
            can create space to feel comfortably you.
          </p>
        </section>
      </Row>

      {/* ROW 3 */}
      <Row>
        {/* IMAGE: LOGO */}
        <Col className="d-flex justify-content-start">
          <Figure>
            <Figure.Image
              className="logo"
              width={100}
              alt="Logo Bird"
              src={LogoBird}
            />
          </Figure>
        </Col>
      </Row>

      {/* ROW 4 */}
      {/* CONTACT DETAILS */}
      <div className="aboutContactContainer">
        <Row>
          <Col>
            <h3>Boutique & Showroom</h3>
            <div className="aboutContact">
              <p>Kuglegårdsvej 1-5</p>
              <p>1434 Copenhagen K</p>
              <p>Denmark</p>
              <p>Phone: +45 31 38 20 51</p>
            </div>
          </Col>
          <Col>
            <div className="aboutContact">
              <h3>Opening Hours</h3>
              <p>Monday - Friday: 10 AM-6 PM</p>
              <p>Saturday - Sunday: 10 AM-4 PM</p>
            </div>
          </Col>
          <Col>
            <h3>Parking</h3>
            <div className="aboutContact">
              <p>
                We offer free parking for all our customers right outside our
                Boutique.
              </p>
            </div>{" "}
          </Col>
        </Row>
      </div>
    </Container>
  );
}
