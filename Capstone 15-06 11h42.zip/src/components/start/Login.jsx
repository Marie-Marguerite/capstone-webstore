// Login.jsx
import { useNavigate } from "react-router-dom";
import LoginForm from "./LoginForm";

export default function Login() {
  // Prep navigate to register page
  const navigateRegister = useNavigate();
  const handleClick = () => {
    navigateRegister("/register");
  };

  return (
    <>
      <LoginForm />
      {/* Button to navigate to register page */}
      <button className="login-registerHereButton" onClick={handleClick}>
        REGISTER HERE
      </button>
    </>
  );
}
