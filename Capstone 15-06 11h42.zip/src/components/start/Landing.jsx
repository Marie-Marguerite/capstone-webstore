// Landing.jsx
import { useDispatch, useSelector } from "react-redux";
import { logoutUser } from "../../redux/UserSlice";
import About from "./About";
import Footer from "../general/Footer";



export default function Landing() {
  // VARIABLES AND HOOKS
  const dispatch = useDispatch();
  const loggedInUser = useSelector((state) => state.user.loggedInUser);

  // HANDLE LOGOUT
  const handleLogout = () => {
    dispatch(logoutUser());
  };

  return (
    <div className="homeContainer">
      {/* Welcome message */}
      <h1>Welcome, {loggedInUser?.firstName}.</h1>
      {/* Log out button */}
      <button onClick={handleLogout}>LOGOUT</button>
      {/* About */}
      <About />
      <Footer/>
    </div>
  );
}
