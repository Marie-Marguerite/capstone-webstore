// Register.jsx
import { useNavigate } from "react-router-dom";
import RegistrationForm from "./RegistrationForm";

export default function Register() {
  // Prep navigate to login page
  const navigateLogin = useNavigate();
  const handleClick = () => {
    navigateLogin("/login");
  };

  return (
    <>
      <RegistrationForm />
      {/* Button to navigate to login page */}
      <button className="login-registerHereButton" onClick={handleClick}>
        LOGIN HERE
      </button>
    </>
  );
}
