// UserSlice.js
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  users: JSON.parse(localStorage.getItem("users")) || [], // registered users
  loggedInUser: JSON.parse(localStorage.getItem("loggedInUser")) || null,
  loginError: false,
  registrationSuccess: false,
};

const UserSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    //* ADD/REGISTER NEW USER
    registerUser: (state, action) => {
      const newUser = {
        email: action.payload.email.trim().toLowerCase(),
        password: action.payload.password.trim(),
      };
      //  FORMAT USER NAME FOR DISPLAY: Capitalize the first letter of each word in the user input & handle hyphenated names
      //  - format name
      const name = newUser.firstName.trim();
      const formattedName = name
        .split(" ")
        .map((word) =>
          word
            .split("-")
            .map(
              (part) =>
                part.charAt(0).toUpperCase() + part.slice(1).toLowerCase()
            )
            .join("-")
        )
        .join(" ");
      //  - add formatted name to existing user details
      const newUserWithFormattedName = {
        ...newUser,
        firstName: formattedName,
      };
      //  ADD FORMATTED USER
      state.users.push(newUserWithFormattedName);
      localStorage.setItem("users", JSON.stringify(state.users));
      //  SET SUCCESSFUL REGISTRATION TO TRUE
      state.registrationSuccess = true;
      state.loginError = false;
    },

    //* CLEAR REGISTRATION SUCCESS
    clearRegistrationSuccess: (state) => {
      state.registrationSuccess = false;
    },

    //* LOGIN USER
    loginUser: (state, action) => {
      //  VALIDATE LOGIN DETAILS AGAINST REGISTERED USERS
      const { email, password } = action.payload;
      const foundUser = state.users.find(
        (user) =>
          //  - find match: email
          user.email.trim().toLowerCase() === email.toLowerCase() &&
          //  - find match: password
          user.password === password
      );
      //  IF VALID USER = LOGIN (successful login)
      if (foundUser) {
        // set login as true
        state.loggedInUser = foundUser;
        state.loginError = false;
        localStorage.setItem("loggedInUser", JSON.stringify(foundUser));
      }
      //  IF NO USER MATCH = ERROR (unsuccessful login)
      else {
        state.loggedInUser = null;
        state.loginError = true;
      }
    },
    //* LOGOUT USER
    logoutUser: (state) => {
      state.loggedInUser = null;
      localStorage.removeItem("loggedInUser");
    },
  },
});

export const { registerUser, clearRegistrationSuccess, loginUser, logoutUser } =
  UserSlice.actions;

export default UserSlice.reducer;
