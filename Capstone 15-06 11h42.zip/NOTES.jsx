//* LOGIN FORM
// Replace this:
onSubmit: (values, { resetForm, setTouched }) => {
  dispatch(loginUser({ email: values.email, password: values.password }));
  resetForm();
  setTouched({});
}

// With this:
onSubmit: async (values, { resetForm, setTouched }) => {
  await dispatch(loginUser({ email: values.email, password: values.password }));

  const isSuccess = store.getState().user.loggedInUser; // or use a selector if outside
  if (isSuccess) {
    resetForm();
    setTouched({});
  }
}

// Option B — Auto-redirect after 5 sec
// Add this in your useEffect that runs when registrationSuccess becomes true:
useEffect(() => {
  if (registrationSuccess) {
    const redirectTimer = setTimeout(() => {
      dispatch(clearRegistrationSuccess());
      navigate("/login");
    }, 5000);
    return () => clearTimeout(redirectTimer);
  }
}, [registrationSuccess, dispatch, navigate]);




//* ABOUT
/* 🧠 Suggested Improvement for Later (when you're ready)
Once your Capstone is stable and working:

Split layout into smaller components like:

AboutDescription.jsx

AboutImages.jsx

AboutContact.jsx
This will clean up the About component and help you later with styling and reuse.
*/




